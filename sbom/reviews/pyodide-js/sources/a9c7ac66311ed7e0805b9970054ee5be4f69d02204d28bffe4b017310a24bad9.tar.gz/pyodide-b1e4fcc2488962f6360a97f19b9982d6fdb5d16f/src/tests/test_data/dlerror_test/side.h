int
side_func();
